#!/bin/bash
cd ..
source ./venv-opencv/bin/activate
python ./clip_demo_app_opencv/dx_realtime_demo.py
