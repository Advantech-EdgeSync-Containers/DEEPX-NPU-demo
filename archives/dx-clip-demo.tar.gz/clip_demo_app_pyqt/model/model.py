from clip_demo_app_pyqt.common.base import Base

class Model(Base):
    def __init__(self):
        Base.__init__(self)
