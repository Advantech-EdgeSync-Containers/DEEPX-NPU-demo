// Copyright (c) 2022 DEEPX Corporation. All rights reserved.
// Licensed under the MIT License.


#include "dxrt/common.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
int dxrt_service_main(int argc, char* argv[]);



#ifdef __linux__
#include <dirent.h>
#include <unistd.h>
bool hasOtherProcess() {
    const std::string& processName = "dxrtd";
    pid_t myPid = getpid(); // Get Current Process PID

    // /proc Directory Open
    DIR* procDir = opendir("/proc");
    if (!procDir) {
        perror("opendir");
        return false;
    }

    struct dirent* entry;
    while ((entry = readdir(procDir)) != nullptr) {
        // Check if directory name is digit(process)
        std::string dirName(entry->d_name);
        if (!std::all_of(dirName.begin(), dirName.end(), ::isdigit)) {
            continue;
        }

        pid_t pid = std::stoi(dirName);
        if (pid == myPid) {
            continue; // Exclude self 
        }

        // /proc/<pid>/cmdline file open
        std::ifstream cmdlineFile("/proc/" + dirName + "/cmdline");
        if (!cmdlineFile.is_open()) {
            continue;
        }

        // read from cmdline
        std::string cmdline;
        std::getline(cmdlineFile, cmdline, '\0'); // read first things seperated by NULL
        cmdlineFile.close();

        // Check for process name
        if (cmdline.find(processName) != std::string::npos) {
            closedir(procDir);
            return true;
        }
    }

    closedir(procDir);
    return false;
}
#elif _WIN32
#include <windows.h>
#include <tlhelp32.h>
// Check for other process with has same name
bool hasOtherProcess() {
    const std::string processName = "dxrtd.exe";
    DWORD myPid = GetCurrentProcessId(); // Get current process PID

    // Get process snapshots
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        std::cerr << "Failed to create process snapshot.\n";
        return false;
    }

    PROCESSENTRY32 processEntry;
    processEntry.dwSize = sizeof(PROCESSENTRY32);

    // Get first process
    if (!Process32First(hSnapshot, &processEntry)) {
        std::cerr << "Failed to retrieve first process.\n";
        CloseHandle(hSnapshot);
        return false;
    }

    // iterate process list
    do {
        // If name is equal and pid is not equal
        if (processName == processEntry.szExeFile && myPid != processEntry.th32ProcessID) {
            CloseHandle(hSnapshot);
            return true; // Other instance running
        }
    } while (Process32Next(hSnapshot, &processEntry));

    CloseHandle(hSnapshot);
    return false; // No Other instance
}
#endif

int main(int argc, char* argv[])
{
    std::ignore = argc;
    std::ignore = argv;
    if (hasOtherProcess())
    {
        std::cout << "Other instance of dxrtd is running" << std::endl;
        return -1;
    }
#ifdef USE_SERVICE
    return dxrt_service_main(argc, argv);
#else
    std::cout << "USE_SERVICE is not set, so dxrt_service will not work" << std::endl;
    return -1;
#endif
}