var searchData=
[
  ['tensor_97',['Tensor',['../classdxrt_1_1Tensor.html',1,'dxrt']]]
];
