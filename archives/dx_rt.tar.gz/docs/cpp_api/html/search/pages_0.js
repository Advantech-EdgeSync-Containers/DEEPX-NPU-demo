var searchData=
[
  ['deprecated_20list_185',['Deprecated List',['../deprecated.html',1,'']]],
  ['dx_20runtime_20api_186',['DX Runtime API',['../index.html',1,'']]]
];
