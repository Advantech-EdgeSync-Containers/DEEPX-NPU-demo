var searchData=
[
  ['name_71',['name',['../classdxrt_1_1InferenceEngine.html#a3fb16094508bd367cc4971238f002765',1,'dxrt::InferenceEngine']]],
  ['npuclock_72',['NpuClock',['../classdxrt_1_1DeviceStatus.html#a6b59c9c20e5316cb4fd6ff585a14052c',1,'dxrt::DeviceStatus']]],
  ['npustatusstr_73',['NpuStatusStr',['../classdxrt_1_1DeviceStatus.html#a48832bfd9871793c559e737cb332c109',1,'dxrt::DeviceStatus']]]
];
