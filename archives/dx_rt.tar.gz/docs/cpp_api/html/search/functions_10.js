var searchData=
[
  ['validatedevice_178',['ValidateDevice',['../classdxrt_1_1InferenceEngine.html#aef4c9502a5d5a9d256d3899391376aba',1,'dxrt::InferenceEngine']]],
  ['voltage_179',['Voltage',['../classdxrt_1_1DeviceStatus.html#aeeede2b02a7384915a161f522dbebaa0',1,'dxrt::DeviceStatus']]]
];
