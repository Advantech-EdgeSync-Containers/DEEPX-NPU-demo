var searchData=
[
  ['bitmatch_5fmask_3',['bitmatch_mask',['../classdxrt_1_1InferenceEngine.html#a0e23ce411e6d6d45e6939fe1b3a7e700',1,'dxrt::InferenceEngine']]],
  ['boardtypestr_4',['BoardTypeStr',['../classdxrt_1_1DeviceStatus.html#a01e24b6255ff24953962779fda9c8fd1',1,'dxrt::DeviceStatus']]],
  ['boundoption_5',['boundOption',['../classdxrt_1_1InferenceOption.html#a9fd270a5eeeb1a14ce5f133c16c30d55',1,'dxrt::InferenceOption']]]
];
