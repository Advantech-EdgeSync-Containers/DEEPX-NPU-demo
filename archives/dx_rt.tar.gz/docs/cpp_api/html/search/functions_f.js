var searchData=
[
  ['task_5forder_176',['task_order',['../classdxrt_1_1InferenceEngine.html#a22087ed8a6839bfc1c4a6b9c21629236',1,'dxrt::InferenceEngine']]],
  ['temperature_177',['Temperature',['../classdxrt_1_1DeviceStatus.html#ab241b8ae83657a81f973023d61b28d36',1,'dxrt::DeviceStatus']]]
];
