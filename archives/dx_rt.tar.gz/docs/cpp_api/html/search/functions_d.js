var searchData=
[
  ['registercallback_169',['RegisterCallBack',['../classdxrt_1_1InferenceEngine.html#a3d3fc75faa79470d9a3bdbdc61561a3a',1,'dxrt::InferenceEngine::RegisterCallBack(std::function&lt; int(TensorPtrs &amp;outputs, void *userArg)&gt; callbackFunc)'],['../classdxrt_1_1InferenceEngine.html#a1d8b33fa324a48b43433c401bd54280a',1,'dxrt::InferenceEngine::RegisterCallback(std::function&lt; int(TensorPtrs &amp;outputs, void *userArg)&gt; callbackFunc)']]],
  ['run_170',['Run',['../classdxrt_1_1InferenceEngine.html#a88cea5324cbeb436034adb60cf31050f',1,'dxrt::InferenceEngine::Run(void *inputPtr, void *userArg=nullptr, void *outputPtr=nullptr)'],['../classdxrt_1_1InferenceEngine.html#ab54d666cc65cef4d6ae2fe4c300d7ba1',1,'dxrt::InferenceEngine::Run(const std::vector&lt; void * &gt; &amp;inputBuffers, const std::vector&lt; void * &gt; &amp;outputBuffers, const std::vector&lt; void * &gt; &amp;userArgs={})']]],
  ['runasync_171',['RunAsync',['../classdxrt_1_1InferenceEngine.html#af3006c9a7183f7e42d1528aa8a6fea24',1,'dxrt::InferenceEngine']]],
  ['runbenchmark_172',['RunBenchmark',['../classdxrt_1_1InferenceEngine.html#a3846a2f47ea39933136e589aad036eb0',1,'dxrt::InferenceEngine::RunBenchmark(int num, void *inputPtr=nullptr)'],['../classdxrt_1_1InferenceEngine.html#ab0c6629f048341d62bfa3a400c90e827',1,'dxrt::InferenceEngine::RunBenchMark(int num, void *inputPtr=nullptr)']]]
];
