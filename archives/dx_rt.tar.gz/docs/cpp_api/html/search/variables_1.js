var searchData=
[
  ['defaultinferenceoption_182',['DefaultInferenceOption',['../namespacedxrt.html#aab5060680ba2f567f47f8868cd8b1f00',1,'dxrt']]],
  ['devices_183',['devices',['../classdxrt_1_1InferenceOption.html#ae98837ff566fe2b089a5b1bf07feb48c',1,'dxrt::InferenceOption']]]
];
