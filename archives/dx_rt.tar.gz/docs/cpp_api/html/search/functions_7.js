var searchData=
[
  ['inference_5ftime_149',['inference_time',['../classdxrt_1_1InferenceEngine.html#aad2f3b616e0e996b66ef7df37dc16a85',1,'dxrt::InferenceEngine']]],
  ['inferenceengine_150',['InferenceEngine',['../classdxrt_1_1InferenceEngine.html#aed622c0fa566620899c9e7e26011bacd',1,'dxrt::InferenceEngine']]],
  ['input_5fsize_151',['input_size',['../classdxrt_1_1InferenceEngine.html#a96c4e5953a0daf4a1c886002c052a6ba',1,'dxrt::InferenceEngine']]],
  ['inputs_152',['inputs',['../classdxrt_1_1InferenceEngine.html#afbee8b031fdd6c0a3916ed00d08c9cd8',1,'dxrt::InferenceEngine::inputs(void *ptr=nullptr, uint64_t phyAddr=0)'],['../classdxrt_1_1InferenceEngine.html#af81b48e8ccd95953dd9bc483e5ec678b',1,'dxrt::InferenceEngine::inputs(int devId)']]],
  ['is_5fppu_153',['is_PPU',['../classdxrt_1_1InferenceEngine.html#a9aeb596b415843e7e318c47938444259',1,'dxrt::InferenceEngine']]],
  ['isppu_154',['IsPPU',['../classdxrt_1_1InferenceEngine.html#ab6fd915af259467afe1681098b315dca',1,'dxrt::InferenceEngine']]]
];
