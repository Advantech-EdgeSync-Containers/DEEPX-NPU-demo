var searchData=
[
  ['bitmatch_5fmask_102',['bitmatch_mask',['../classdxrt_1_1InferenceEngine.html#a0e23ce411e6d6d45e6939fe1b3a7e700',1,'dxrt::InferenceEngine']]],
  ['boardtypestr_103',['BoardTypeStr',['../classdxrt_1_1DeviceStatus.html#a01e24b6255ff24953962779fda9c8fd1',1,'dxrt::DeviceStatus']]]
];
