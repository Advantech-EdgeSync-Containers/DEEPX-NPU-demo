var searchData=
[
  ['add_99',['Add',['../classdxrt_1_1Profiler.html#a478017e84d8227f3a0fbfa62b554b2c6',1,'dxrt::Profiler']]],
  ['addtimepoint_100',['AddTimePoint',['../classdxrt_1_1Profiler.html#ac2298a3357d6674660bfe19d1b4e399a',1,'dxrt::Profiler']]],
  ['allmemoryinfostr_101',['AllMemoryInfoStr',['../classdxrt_1_1DeviceStatus.html#af1306b887625b2fa0336248560f4b262',1,'dxrt::DeviceStatus']]]
];
