var searchData=
[
  ['data_107',['data',['../classdxrt_1_1Tensor.html#a199c03999346426d6c70f76ec051a0b2',1,'dxrt::Tensor']]],
  ['ddrbiterrstr_108',['DdrBitErrStr',['../classdxrt_1_1DeviceStatus.html#aa5c2e549574f03693d589e029f312224',1,'dxrt::DeviceStatus']]],
  ['ddrstatusstr_109',['DdrStatusStr',['../classdxrt_1_1DeviceStatus.html#a59146c2ca089105772585c5d4b642123',1,'dxrt::DeviceStatus']]],
  ['devicetypestr_110',['DeviceTypeStr',['../classdxrt_1_1DeviceStatus.html#a21331342e0d75e651a29e20eb8d8a590',1,'dxrt::DeviceStatus']]],
  ['devicetypeword_111',['DeviceTypeWord',['../classdxrt_1_1DeviceStatus.html#a2c6eefd42b1aed7622d365cadd7bb4d4',1,'dxrt::DeviceStatus']]],
  ['devicevariantstr_112',['DeviceVariantStr',['../classdxrt_1_1DeviceStatus.html#a5d5c52d00eb62e82fe8b1b91da2c8a3c',1,'dxrt::DeviceStatus']]],
  ['dispose_113',['Dispose',['../classdxrt_1_1InferenceEngine.html#af3feefee6373ecfe7fe5b9b84501a723',1,'dxrt::InferenceEngine']]],
  ['dmachannel_114',['DmaChannel',['../classdxrt_1_1DeviceStatus.html#a69ff2ada536e5098dc7a226eb9be974e',1,'dxrt::DeviceStatus']]],
  ['dvfsstateinfostr_115',['DvfsStateInfoStr',['../classdxrt_1_1DeviceStatus.html#aa5e180be2e587c87fbbab55765adff65',1,'dxrt::DeviceStatus']]]
];
